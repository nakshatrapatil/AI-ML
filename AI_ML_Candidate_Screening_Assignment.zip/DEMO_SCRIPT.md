# 5–7 Minute Demo Video Script

## 1. Introduction — 30 sec

"Hi, this is my AI-powered role-based candidate screening system. The goal is to simulate a technical interview where questions are dynamically generated from the candidate's resume, selected role and a role-specific knowledge base."

## 2. Architecture — 60 sec

Show the repository.

Explain:

- React handles resume upload, role selection and interview UI.
- FastAPI handles the application workflow.
- SQLite stores sessions, questions, answers and scores.
- Chroma stores embedded knowledge chunks.
- Sentence Transformers create embeddings.
- The LLM generates grounded questions and evaluates answers.

## 3. Knowledge ingestion — 45 sec

Show:

```bash
python scripts/ingest_knowledge.py
```

Explain that the final submission uses the company-provided ML book as the primary knowledge source. The included sample notes are only a runnable demonstration corpus.

## 4. Start interview — 60 sec

Upload `demo_resume.txt`.

Select `AI/ML Engineer`.

Click Start Interview.

Explain:

"First the backend parses the resume and extracts skills and topics. It then constructs a query using the selected role and those resume signals. Chroma retrieves relevant knowledge chunks. Those chunks are passed to the LLM to create a personalized technical question."

## 5. Answer + adaptive flow — 90 sec

Submit an answer.

Explain:

"The answer is persisted. It is evaluated against the retrieved context. For the next question, the previous answer becomes part of the retrieval query, so the interview can adapt."

Show Swagger if useful.

## 6. Final result — 45 sec

Complete five questions.

Show score, summary, strengths and improvement areas.

Explain:

"The system maintains traceability from retrieved context to question to answer and evaluation."

## 7. Closing — 30 sec

Mention future improvements:

- PostgreSQL/pgvector
- reranking
- authentication
- recruiter dashboard
- speech interview
- automated testing and CI/CD
