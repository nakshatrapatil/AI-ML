# AI/ML Candidate Screening System — RAG Interviewer

A complete full-stack assignment implementation for the **AI/ML & Backend Engineering Intern** role.

## What it demonstrates

- React frontend
- FastAPI backend
- SQLite persistence with SQLAlchemy
- Resume PDF/TXT parsing
- Resume skill/topic extraction
- Role-specific RAG knowledge ingestion
- Sentence-Transformer embeddings
- Chroma vector database
- Dynamic retrieval using resume + selected role
- LLM-based interview question generation
- Answer storage and adaptive follow-up questions
- Final interview summary with basic scoring
- Traceability: every question stores the retrieved context/chunk IDs
- Environment-based configuration
- Modular service architecture
- Docker Compose support

## Architecture

```text
React UI
   |
   v
FastAPI REST API
   |
   +--> Resume Parser
   +--> RAG Service
   |      +--> ChromaDB
   |      +--> Sentence Transformers
   |      +--> Role knowledge base
   |
   +--> LLM Service
   +--> Interview Service
   |
   v
SQLite Database
```

## Project structure

```text
aiml_candidate_screening/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── routes_health.py
│   │   │   ├── routes_interview.py
│   │   │   └── routes_knowledge.py
│   │   ├── core/
│   │   │   └── config.py
│   │   ├── db/
│   │   │   ├── database.py
│   │   │   └── models.py
│   │   ├── schemas/
│   │   │   └── interview.py
│   │   ├── services/
│   │   │   ├── llm_service.py
│   │   │   ├── rag_service.py
│   │   │   ├── resume_service.py
│   │   │   └── interview_service.py
│   │   └── main.py
│   ├── data/
│   │   └── knowledge_base/
│   │       ├── ai_ml/
│   │       │   └── sample_ml_notes.txt
│   │       └── README.md
│   ├── scripts/
│   │   └── ingest_knowledge.py
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── api.js
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── package.json
│   └── vite.config.js
├── docker-compose.yml
└── .gitignore
```

## Important: knowledge base requirement

The assignment says the supplied book should be the primary RAG source.

The included `sample_ml_notes.txt` is only a **small starter knowledge base** so the application can be tested immediately. For your final submission, download the book(s) supplied by the company and place them under:

```text
backend/data/knowledge_base/ai_ml/
```

For example:

```text
backend/data/knowledge_base/ai_ml/tom_mitchell_machine_learning.pdf
```

Then run ingestion again.

Do not commit copyrighted PDFs to GitHub unless you have permission to redistribute them. Instead, explain in your README/demo that the provided book was used locally as the primary knowledge source.

## Local setup

### 1. Backend

Python 3.10+ is recommended.

```bash
cd backend
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Copy:

```text
.env.example -> .env
```

Set your LLM key in `.env`:

```env
OPENAI_API_KEY=your_key_here
```

If you use another OpenAI-compatible provider, set `OPENAI_BASE_URL` and `OPENAI_MODEL`.

Ingest the knowledge base:

```bash
python scripts/ingest_knowledge.py
```

Start API:

```bash
uvicorn app.main:app --reload
```

Backend:

```text
http://localhost:8000
```

Swagger:

```text
http://localhost:8000/docs
```

### 2. Frontend

Open another terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal, normally:

```text
http://localhost:5173
```

## Demo flow

1. Upload a resume PDF/TXT.
2. Select `AI/ML Engineer`.
3. Click **Start Interview**.
4. The backend extracts resume information.
5. It builds a query from role + skills + resume topics.
6. Chroma retrieves relevant knowledge chunks.
7. The LLM generates a grounded question.
8. Candidate submits an answer.
9. The answer is stored.
10. The next question can adapt based on the answer.
11. After 5 questions, the system generates a summary.
12. The UI shows score, strengths, improvement areas and question/answer history.

## API flow

```text
POST /api/interviews
    -> create session + parse resume + first RAG question

POST /api/interviews/{session_id}/answer
    -> save answer + retrieve new context + generate next question

GET /api/interviews/{session_id}
    -> session state + Q&A + traceability

POST /api/interviews/{session_id}/complete
    -> final evaluation and summary

POST /api/knowledge/ingest
    -> ingest role-specific TXT/PDF files
```

## Design decisions to explain in the interview

### Why RAG?

The system must ground interview questions in a role-specific corpus instead of asking an LLM to produce generic interview questions.

### Why chunking?

Large documents cannot be sent wholesale for every question. Chunks make retrieval efficient and preserve local context.

### Why overlap?

A small overlap reduces the chance that a concept split across chunk boundaries loses important context.

### Why embeddings?

Embeddings map semantically similar text close together, so a query such as "overfitting prevention" can retrieve relevant content even when the exact words differ.

### Why Chroma?

It is lightweight and simple for an internship assignment. It can later be replaced by PostgreSQL/pgvector or another production vector store.

### Why SQLite?

It provides real persistence without requiring an external database during evaluation. A production deployment can move to PostgreSQL.

### Resume influence

The query contains:
- selected role
- extracted skills
- resume topics
- previous answer (for later questions)

This means the resume actually changes retrieval and question generation.

## Limitations / future improvements

- Add authentication and candidate accounts.
- Use PostgreSQL + pgvector in production.
- Add a reranking model after vector retrieval.
- Add stronger answer evaluation with a rubric per topic.
- Add speech-to-text interview mode.
- Add recruiter dashboard.
- Add asynchronous ingestion for very large corpora.
- Add automated tests and CI/CD.
