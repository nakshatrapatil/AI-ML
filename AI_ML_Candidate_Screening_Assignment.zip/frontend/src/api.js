const API = "http://localhost:8000";

export async function startInterview(role, resume) {
  const form = new FormData();
  form.append("role", role);
  form.append("resume", resume);
  const res = await fetch(`${API}/api/interviews`, { method: "POST", body: form });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function submitAnswer(sessionId, answer) {
  const res = await fetch(`${API}/api/interviews/${sessionId}/answer`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ answer })
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function getSession(sessionId) {
  const res = await fetch(`${API}/api/interviews/${sessionId}`);
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}

export async function completeInterview(sessionId) {
  const res = await fetch(`${API}/api/interviews/${sessionId}/complete`, { method: "POST" });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
