import { useState } from "react";
import { startInterview, submitAnswer, completeInterview } from "./api";

const roles = ["AI/ML Engineer", "Data Scientist", "Applied ML Engineer", "Backend Engineer"];

export default function App() {
  const [step, setStep] = useState("start");
  const [role, setRole] = useState("AI/ML Engineer");
  const [resume, setResume] = useState(null);
  const [session, setSession] = useState(null);
  const [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  async function begin() {
    if (!resume) return setError("Please upload your resume.");
    setBusy(true); setError("");
    try {
      const data = await startInterview(role, resume);
      setSession(data);
      setStep("interview");
    } catch (e) {
      setError(e.message);
    } finally { setBusy(false); }
  }

  async function next() {
    if (!answer.trim()) return;
    setBusy(true); setError("");
    try {
      const data = await submitAnswer(session.session_id, answer);
      setAnswer("");
      setSession(s => ({ ...s, question: data.next_question || s.question }));
      if (data.is_complete) {
        const final = await completeInterview(session.session_id);
        setResult(final);
        setStep("result");
      }
    } catch (e) {
      setError(e.message);
    } finally { setBusy(false); }
  }

  if (step === "result") {
    return (
      <main className="shell">
        <div className="hero compact">
          <span className="badge">Interview Complete</span>
          <h1>Your AI/ML Interview Report</h1>
          <p>Session: {session.session_id}</p>
        </div>
        <section className="card score">
          <div className="score-number">{Math.round(result.score)}<small>/100</small></div>
          <div>
            <h2>Overall assessment</h2>
            <p>{result.summary}</p>
          </div>
        </section>
        <div className="grid">
          <section className="card">
            <h3>Strengths</h3>
            <ul>{result.strengths.map((x, i) => <li key={i}>{x}</li>)}</ul>
          </section>
          <section className="card">
            <h3>Improve</h3>
            <ul>{result.improvements.map((x, i) => <li key={i}>{x}</li>)}</ul>
          </section>
        </div>
        <button onClick={() => location.reload()}>Start New Interview</button>
      </main>
    );
  }

  if (step === "interview") {
    return (
      <main className="shell">
        <div className="topbar">
          <div><span className="badge">Live Interview</span><h1>{session.role}</h1></div>
          <div className="pill">Question {session.question.question_number} / 5</div>
        </div>
        <section className="card profile">
          <strong>Resume signals:</strong>
          <div className="chips">
            {(session.resume_summary.skills || []).map(s => <span key={s}>{s}</span>)}
          </div>
        </section>
        <section className="card question">
          <div className="label">{session.question.topic} · {session.question.difficulty}</div>
          <h2>{session.question.question}</h2>
          <textarea value={answer} onChange={e => setAnswer(e.target.value)}
            placeholder="Explain your answer clearly. Include an example if possible..." />
          <button disabled={busy || !answer.trim()} onClick={next}>
            {busy ? "Evaluating..." : "Submit Answer"}
          </button>
        </section>
        {error && <div className="error">{error}</div>}
      </main>
    );
  }

  return (
    <main className="shell">
      <div className="hero">
        <span className="badge">RAG-Powered Technical Screening</span>
        <h1>AI Interviewer</h1>
        <p>Upload your resume and let the system build a personalized technical interview from a role-specific knowledge base.</p>
      </div>
      <section className="card">
        <label>Target role</label>
        <select value={role} onChange={e => setRole(e.target.value)}>
          {roles.map(r => <option key={r}>{r}</option>)}
        </select>

        <label>Resume (PDF or TXT)</label>
        <div className="upload">
          <input type="file" accept=".pdf,.txt" onChange={e => setResume(e.target.files[0])} />
          {resume && <span>{resume.name}</span>}
        </div>

        <div className="flow">
          <div>01<br/><span>Resume</span></div>
          <div>02<br/><span>Retrieve</span></div>
          <div>03<br/><span>Question</span></div>
          <div>04<br/><span>Evaluate</span></div>
        </div>

        {error && <div className="error">{error}</div>}
        <button disabled={busy} onClick={begin}>{busy ? "Preparing..." : "Start Interview"}</button>
      </section>
      <p className="note">Questions are generated using retrieved role-specific context and candidate resume signals.</p>
    </main>
  );
}
