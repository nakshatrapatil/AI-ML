import re
from pathlib import Path
from pypdf import PdfReader

KNOWN_SKILLS = [
    "python", "java", "sql", "mysql", "postgresql", "fastapi", "flask",
    "django", "react", "javascript", "typescript", "machine learning",
    "deep learning", "scikit-learn", "pandas", "numpy", "tensorflow",
    "pytorch", "streamlit", "power bi", "docker", "git", "aws", "azure",
    "api", "rest api", "playwright", "pytest", "selenium", "nlp",
    "computer vision", "llm", "rag", "generative ai"
]

TOPIC_MAP = {
    "python": "Python programming",
    "sql": "SQL and databases",
    "fastapi": "backend APIs",
    "flask": "backend APIs",
    "django": "backend APIs",
    "machine learning": "machine learning fundamentals",
    "deep learning": "deep learning",
    "scikit-learn": "ML implementation",
    "pandas": "data processing",
    "numpy": "numerical computing",
    "tensorflow": "deep learning frameworks",
    "pytorch": "deep learning frameworks",
    "rag": "retrieval augmented generation",
    "llm": "large language models",
    "generative ai": "generative AI",
    "nlp": "natural language processing",
    "computer vision": "computer vision",
    "docker": "deployment and containers",
    "rest api": "API design",
    "api": "API design"
}

def parse_resume(path: str) -> str:
    p = Path(path)
    if p.suffix.lower() == ".pdf":
        reader = PdfReader(str(p))
        return "\n".join(page.extract_text() or "" for page in reader.pages).strip()
    return p.read_text(encoding="utf-8", errors="ignore").strip()

def extract_resume_profile(text: str) -> dict:
    lower = text.lower()
    skills = [skill for skill in KNOWN_SKILLS if re.search(r"\b" + re.escape(skill) + r"\b", lower)]
    topics = []
    for skill in skills:
        topic = TOPIC_MAP.get(skill)
        if topic and topic not in topics:
            topics.append(topic)

    sections = {}
    for heading in ["projects", "experience", "education", "skills", "certifications"]:
        m = re.search(rf"{heading}\s*[:\-]?\s*(.*?)(?=\n[A-Z][A-Za-z ]{{2,30}}\s*[:\-]|\Z)", text, re.I | re.S)
        if m:
            sections[heading] = m.group(1).strip()[:1500]

    return {
        "skills": skills,
        "topics": topics,
        "sections": sections,
        "text_preview": text[:1200]
    }
