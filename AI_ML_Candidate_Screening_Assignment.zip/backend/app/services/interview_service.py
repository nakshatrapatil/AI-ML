import json
import uuid
from sqlalchemy.orm import Session
from app.core.config import settings
from app.db.models import InterviewSession, InterviewTurn
from app.services.rag_service import RAGService
from app.services.llm_service import LLMService
from app.services.resume_service import extract_resume_profile

rag = RAGService()
llm = LLMService()

ROLE_TO_FOLDER = {
    "AI/ML Engineer": "ai_ml",
    "Data Scientist": "ai_ml",
    "Applied ML Engineer": "ai_ml",
    "Backend Engineer": "backend"
}

def build_query(role, profile, previous_answer=""):
    skills = ", ".join(profile.get("skills", []))
    topics = ", ".join(profile.get("topics", []))
    return f"Role: {role}. Candidate skills: {skills}. Candidate topics: {topics}. Previous answer: {previous_answer[-1200:]}"

def create_interview(db: Session, role: str, resume_text: str):
    profile = extract_resume_profile(resume_text)
    session_id = uuid.uuid4().hex
    session = InterviewSession(
        id=session_id,
        role=role,
        resume_text=resume_text,
        skills=json.dumps(profile["skills"]),
        topics=json.dumps(profile["topics"]),
        question_count=0,
        status="active"
    )
    db.add(session)
    db.commit()

    query = build_query(role, profile)
    retrieved = rag.retrieve(query, ROLE_TO_FOLDER.get(role, "ai_ml"))
    context = "\n\n".join(x["text"] for x in retrieved)

    generated = llm.generate_question(role, profile, context)
    turn = InterviewTurn(
        session_id=session_id,
        question_number=1,
        question=generated["question"],
        topic=generated.get("topic", ""),
        difficulty=generated.get("difficulty", "medium"),
        retrieved_context=context,
        source_metadata=json.dumps([x["metadata"] | {"id": x["id"]} for x in retrieved])
    )
    db.add(turn)
    session.question_count = 1
    db.commit()
    return session, profile, turn, retrieved

def answer_and_next(db: Session, session: InterviewSession, answer: str):
    turns = sorted(session.turns, key=lambda x: x.question_number)
    current = turns[-1]
    eval_result = llm.evaluate_answer(current.question, answer, current.retrieved_context)
    current.answer = answer
    current.answer_score = float(eval_result["score"])
    current.feedback = eval_result["feedback"]
    db.commit()

    if len(turns) >= settings.max_questions:
        return current, None, []

    profile = {
        "skills": json.loads(session.skills or "[]"),
        "topics": json.loads(session.topics or "[]"),
        "text_preview": session.resume_text[:1200]
    }
    query = build_query(session.role, profile, answer)
    retrieved = rag.retrieve(query, ROLE_TO_FOLDER.get(session.role, "ai_ml"))
    context = "\n\n".join(x["text"] for x in retrieved)
    generated = llm.generate_question(session.role, profile, context, answer)

    next_turn = InterviewTurn(
        session_id=session.id,
        question_number=len(turns) + 1,
        question=generated["question"],
        topic=generated.get("topic", ""),
        difficulty=generated.get("difficulty", "medium"),
        retrieved_context=context,
        source_metadata=json.dumps([x["metadata"] | {"id": x["id"]} for x in retrieved])
    )
    db.add(next_turn)
    session.question_count = len(turns) + 1
    db.commit()
    return current, next_turn, retrieved

def complete_interview(db: Session, session: InterviewSession):
    turns = sorted(session.turns, key=lambda x: x.question_number)
    result = llm.summarize(session.role, turns)
    session.status = "completed"
    session.score = float(result["score"])
    session.summary = result["summary"]
    db.commit()
    return result
