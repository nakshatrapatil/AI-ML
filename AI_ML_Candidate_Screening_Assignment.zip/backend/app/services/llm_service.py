import json
from openai import OpenAI
from app.core.config import settings

class LLMService:
    def __init__(self):
        self.client = None
        if settings.openai_api_key:
            kwargs = {"api_key": settings.openai_api_key}
            if settings.openai_base_url:
                kwargs["base_url"] = settings.openai_base_url
            self.client = OpenAI(**kwargs)

    def _fallback_question(self, role, topic, difficulty):
        return f"For an {role} candidate, explain {topic} and describe how you would apply it in a real project. Mention one practical trade-off."

    def generate_question(self, role, resume_profile, context, previous_answer=""):
        topic = resume_profile["topics"][0] if resume_profile.get("topics") else "machine learning fundamentals"
        if not self.client:
            return {
                "question": self._fallback_question(role, topic, "medium"),
                "topic": topic,
                "difficulty": "medium",
                "reason": "Generated from retrieved role knowledge and resume topic."
            }

        prompt = f"""
You are a technical interviewer for the role: {role}.

Candidate resume profile:
{json.dumps(resume_profile, indent=2)}

Retrieved knowledge context:
{context}

Previous answer, if any:
{previous_answer}

Generate ONE technical interview question. It must be grounded in the retrieved context,
personalized to the resume, and appropriate for the role. Avoid generic questions.
Prefer conceptual + applied reasoning. Do not ask for information absent from the context.

Return ONLY valid JSON:
{{
  "question": "...",
  "topic": "...",
  "difficulty": "easy|medium|hard",
  "reason": "short explanation of why this question was selected"
}}
"""
        response = self.client.chat.completions.create(
            model=settings.openai_model,
            temperature=0.4,
            messages=[
                {"role": "system", "content": "You create grounded technical interview questions."},
                {"role": "user", "content": prompt}
            ]
        )
        content = response.choices[0].message.content.strip()
        if content.startswith("```"):
            content = content.strip("`")
            if content.startswith("json"):
                content = content[4:]
        return json.loads(content)

    def evaluate_answer(self, question, answer, context):
        if not self.client:
            length_score = min(10, max(3, len(answer.split()) / 8))
            return {
                "score": round(length_score, 1),
                "feedback": "Answer recorded. For a stronger answer, include the concept, a practical example, and trade-offs."
            }

        prompt = f"""
Evaluate this technical interview answer.

Question:
{question}

Candidate answer:
{answer}

Reference knowledge:
{context}

Score from 0 to 10 based on correctness, relevance, depth and practical understanding.
Do not reward verbosity alone.

Return ONLY JSON:
{{"score": 0, "feedback": "..."}}
"""
        response = self.client.chat.completions.create(
            model=settings.openai_model,
            temperature=0.2,
            messages=[
                {"role": "system", "content": "You are a fair technical interviewer."},
                {"role": "user", "content": prompt}
            ]
        )
        content = response.choices[0].message.content.strip()
        if content.startswith("```"):
            content = content.strip("`")
            if content.startswith("json"):
                content = content[4:]
        return json.loads(content)

    def summarize(self, role, turns):
        if not self.client:
            avg = sum((t.answer_score or 0) for t in turns) / max(len(turns), 1)
            return {
                "score": round(avg * 10, 1),
                "summary": "The candidate completed the structured interview. Review the individual feedback for technical strengths and gaps.",
                "strengths": ["Completed the interview flow", "Provided answers to role-specific questions"],
                "improvements": ["Add more concrete project examples", "Explain trade-offs and edge cases"]
            }

        transcript = "\n\n".join(
            f"Q{i+1}: {t.question}\nA: {t.answer}\nScore: {t.answer_score}"
            for i, t in enumerate(turns)
        )
        prompt = f"""
Summarize a technical interview for role {role}.

{transcript}

Return ONLY JSON:
{{
 "score": 0,
 "summary": "...",
 "strengths": ["..."],
 "improvements": ["..."]
}}
Score should be 0-100.
"""
        response = self.client.chat.completions.create(
            model=settings.openai_model,
            temperature=0.2,
            messages=[{"role": "user", "content": prompt}]
        )
        content = response.choices[0].message.content.strip()
        if content.startswith("```"):
            content = content.strip("`")
            if content.startswith("json"):
                content = content[4:]
        return json.loads(content)
