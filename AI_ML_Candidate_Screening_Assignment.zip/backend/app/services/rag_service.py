import os
import uuid
from pathlib import Path
import chromadb
from sentence_transformers import SentenceTransformer
from pypdf import PdfReader
from app.core.config import settings

class RAGService:
    def __init__(self):
        self.client = chromadb.PersistentClient(path=settings.chroma_path)
        self.collection = self.client.get_or_create_collection(
            name="role_knowledge",
            metadata={"hnsw:space": "cosine"}
        )
        self.embedder = SentenceTransformer("all-MiniLM-L6-v2")

    def _extract_file(self, path: Path) -> str:
        if path.suffix.lower() == ".pdf":
            reader = PdfReader(str(path))
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        return path.read_text(encoding="utf-8", errors="ignore")

    def _chunk(self, text: str, size: int = 1000, overlap: int = 150):
        text = " ".join(text.split())
        chunks = []
        start = 0
        while start < len(text):
            end = min(len(text), start + size)
            chunk = text[start:end]
            if len(chunk.strip()) > 80:
                chunks.append(chunk)
            if end == len(text):
                break
            start = end - overlap
        return chunks

    def ingest_directory(self, directory: str) -> int:
        root = Path(directory)
        count = 0
        for path in root.rglob("*"):
            if path.suffix.lower() not in {".pdf", ".txt"}:
                continue
            role = path.parent.name
            text = self._extract_file(path)
            chunks = self._chunk(text)
            for idx, chunk in enumerate(chunks):
                doc_id = f"{role}-{path.stem}-{idx}-{uuid.uuid4().hex[:8]}"
                embedding = self.embedder.encode(chunk).tolist()
                self.collection.upsert(
                    ids=[doc_id],
                    documents=[chunk],
                    embeddings=[embedding],
                    metadatas=[{
                        "role": role,
                        "source": path.name,
                        "chunk": idx
                    }]
                )
                count += 1
        return count

    def retrieve(self, query: str, role: str, top_k: int | None = None):
        top_k = top_k or settings.top_k
        embedding = self.embedder.encode(query).tolist()
        result = self.collection.query(
            query_embeddings=[embedding],
            n_results=top_k,
            where={"role": role}
        )
        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        ids = result.get("ids", [[]])[0]
        distances = result.get("distances", [[]])[0] if result.get("distances") else []
        return [
            {
                "id": ids[i],
                "text": docs[i],
                "metadata": metas[i],
                "distance": distances[i] if i < len(distances) else None
            }
            for i in range(len(docs))
        ]
