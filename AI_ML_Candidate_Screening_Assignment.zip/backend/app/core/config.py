from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    openai_api_key: str = ""
    openai_base_url: str | None = None
    openai_model: str = "gpt-4o-mini"
    database_url: str = "sqlite:///./screening.db"
    chroma_path: str = "./chroma_db"
    upload_dir: str = "./uploads"
    top_k: int = 5
    max_questions: int = 5

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
