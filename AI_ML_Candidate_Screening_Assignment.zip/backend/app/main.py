from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.db.database import Base, engine
from app.db import models
from app.api.routes_health import router as health_router
from app.api.routes_interview import router as interview_router
from app.api.routes_knowledge import router as knowledge_router

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI/ML Candidate Screening API",
    version="1.0.0",
    description="RAG-powered role-based technical interview system"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router)
app.include_router(interview_router)
app.include_router(knowledge_router)

@app.get("/")
def root():
    return {"message": "AI/ML Candidate Screening API is running", "docs": "/docs"}
