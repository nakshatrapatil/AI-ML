from pydantic import BaseModel, Field
from typing import Any

class StartInterviewResponse(BaseModel):
    session_id: str
    role: str
    resume_summary: dict[str, Any]
    question: dict[str, Any]

class AnswerRequest(BaseModel):
    answer: str = Field(min_length=1, max_length=10000)

class TurnResponse(BaseModel):
    question_number: int
    question: str
    answer: str | None
    topic: str
    difficulty: str
    answer_score: float | None = None
    feedback: str | None = None
    sources: list[dict[str, Any]] = []

class SessionResponse(BaseModel):
    session_id: str
    role: str
    status: str
    question_count: int
    score: float | None
    summary: str | None
    resume_summary: dict[str, Any]
    turns: list[TurnResponse]

class SummaryResponse(BaseModel):
    session_id: str
    score: float
    summary: str
    strengths: list[str]
    improvements: list[str]
