import json
import os
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.db.models import InterviewSession
from app.schemas.interview import AnswerRequest, SessionResponse, StartInterviewResponse, SummaryResponse
from app.services.resume_service import parse_resume
from app.services.interview_service import create_interview, answer_and_next, complete_interview

router = APIRouter(prefix="/api/interviews", tags=["Interviews"])

ALLOWED_ROLES = {"AI/ML Engineer", "Data Scientist", "Applied ML Engineer", "Backend Engineer"}

def serialize_turn(t):
    try:
        sources = json.loads(t.source_metadata or "[]")
    except Exception:
        sources = []
    return {
        "question_number": t.question_number,
        "question": t.question,
        "answer": t.answer,
        "topic": t.topic,
        "difficulty": t.difficulty,
        "answer_score": t.answer_score,
        "feedback": t.feedback,
        "sources": sources
    }

@router.post("", response_model=StartInterviewResponse)
async def start_interview(
    role: str = Form(...),
    resume: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    if role not in ALLOWED_ROLES:
        raise HTTPException(status_code=400, detail="Unsupported role.")
    if not resume.filename.lower().endswith((".pdf", ".txt")):
        raise HTTPException(status_code=400, detail="Only PDF and TXT resumes are supported.")

    os.makedirs("uploads", exist_ok=True)
    path = os.path.join("uploads", resume.filename.replace("/", "_").replace("\\", "_"))
    with open(path, "wb") as f:
        f.write(await resume.read())

    resume_text = parse_resume(path)
    if not resume_text:
        raise HTTPException(status_code=400, detail="Could not extract text from resume.")

    session, profile, turn, retrieved = create_interview(db, role, resume_text)
    return {
        "session_id": session.id,
        "role": role,
        "resume_summary": profile,
        "question": serialize_turn(turn)
    }

@router.post("/{session_id}/answer")
def submit_answer(session_id: str, payload: AnswerRequest, db: Session = Depends(get_db)):
    session = db.get(InterviewSession, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found.")
    if session.status != "active":
        raise HTTPException(status_code=400, detail="Interview is already completed.")

    current, next_turn, retrieved = answer_and_next(db, session, payload.answer)
    return {
        "saved_turn": serialize_turn(current),
        "next_question": serialize_turn(next_turn) if next_turn else None,
        "is_complete": next_turn is None
    }

@router.get("/{session_id}", response_model=SessionResponse)
def get_session(session_id: str, db: Session = Depends(get_db)):
    session = db.get(InterviewSession, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found.")
    return {
        "session_id": session.id,
        "role": session.role,
        "status": session.status,
        "question_count": session.question_count,
        "score": session.score,
        "summary": session.summary,
        "resume_summary": {
            "skills": json.loads(session.skills or "[]"),
            "topics": json.loads(session.topics or "[]")
        },
        "turns": [serialize_turn(t) for t in sorted(session.turns, key=lambda x: x.question_number)]
    }

@router.post("/{session_id}/complete", response_model=SummaryResponse)
def finish(session_id: str, db: Session = Depends(get_db)):
    session = db.get(InterviewSession, session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found.")
    if session.status == "completed":
        turns = session.turns
        return {
            "session_id": session.id,
            "score": session.score or 0,
            "summary": session.summary or "",
            "strengths": [],
            "improvements": []
        }
    result = complete_interview(db, session)
    return {"session_id": session.id, **result}
