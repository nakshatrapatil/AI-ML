from fastapi import APIRouter, HTTPException
from app.services.rag_service import rag
from app.core.config import settings

router = APIRouter(prefix="/api/knowledge", tags=["Knowledge"])

@router.post("/ingest")
def ingest():
    try:
        count = rag.ingest_directory("data/knowledge_base")
        return {"status": "success", "chunks_ingested": count}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
