# Knowledge Base

Put role-specific TXT or PDF files here.

Recommended final assignment setup:

```text
knowledge_base/
  ai_ml/
    supplied_ml_book.pdf
  backend/
    backend_book_or_notes.pdf
```

The application automatically maps folder names to role names.

For this assignment, use the company-provided ML book as the primary source. The included sample notes are only for testing the application before the supplied PDF is added.
